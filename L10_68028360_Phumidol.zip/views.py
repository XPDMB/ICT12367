from django.shortcuts import render, redirect, get_object_or_404
from .models import Person

def index(request):
    if request.method == "POST":
        name = request.POST.get('name')
        age = request.POST.get('age')
        if name and age:
            Person.objects.create(name=name, age=age)
        return redirect('index')

    all_person = Person.objects.all()
    return render(request, 'index.html', {'all_person': all_person})

def edit_person(request, pk):
    person = get_object_or_404(Person, pk=pk)
    if request.method == "POST":
        person.name = request.POST.get('name')
        person.age = request.POST.get('age')
        person.save()
        return redirect('index')
    return render(request, 'edit.html', {'person': person})

def delete_person(request, pk):
    person = get_object_or_404(Person, pk=pk)
    person.delete()
    return redirect('index')
