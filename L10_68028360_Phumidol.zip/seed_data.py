import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'L10_project.settings')
django.setup()

from app.models import Person

# Sample data
data = [
    {'name': 'นายสมบูรณ์ ขุนเทียน', 'age': 45},
    {'name': 'นางสาวมาลี รักชาติ', 'age': 28},
    {'name': 'นายเอกราช ชายเจริญ', 'age': 35},
    {'name': 'นางปราณี มีโชค', 'age': 52},
]

for p in data:
    Person.objects.get_or_create(name=p['name'], age=p['age'])

print("Successfully seeded data!")
